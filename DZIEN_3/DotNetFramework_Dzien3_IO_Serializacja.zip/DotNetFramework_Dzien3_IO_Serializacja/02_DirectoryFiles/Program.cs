using System;
using System.IO;

namespace DirectoryExample
{
    class Program
    {
        static void Main(string[] args)
        {
            string directoryPath = "Logs";

            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
                Console.WriteLine("Utworzono katalog Logs.");
            }

            File.WriteAllText(Path.Combine(directoryPath, "log1.txt"), "Pierwszy log");
            File.WriteAllText(Path.Combine(directoryPath, "log2.txt"), "Drugi log");
            File.WriteAllText(Path.Combine(directoryPath, "log3.txt"), "Trzeci log");

            Console.WriteLine();
            Console.WriteLine("Lista plików w katalogu Logs:");

            string[] files = Directory.GetFiles(directoryPath);

            foreach (string file in files)
            {
                Console.WriteLine(Path.GetFileName(file));
            }

            Console.ReadKey();
        }
    }
}
