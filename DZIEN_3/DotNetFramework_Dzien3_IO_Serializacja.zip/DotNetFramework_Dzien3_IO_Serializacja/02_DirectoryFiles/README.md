# 02 - System plików: katalogi i lista plików

Program tworzy katalog Logs, zapisuje do niego kilka plików i wyświetla ich listę.

Uruchom projekt `.csproj` w Visual Studio albo skopiuj `Program.cs` do aplikacji konsolowej .NET Framework.
