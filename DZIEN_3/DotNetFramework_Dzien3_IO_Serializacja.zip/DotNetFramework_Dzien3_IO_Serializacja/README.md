# .NET Framework - Dzień 3: IO i serializacja

Materiał zawiera 6 osobnych przykładów konsolowych w C# dla .NET Framework 4.7.2.

## Tematy

1. IO: zapis i odczyt pliku tekstowego
2. System plików: katalogi i lista plików
3. Sieć: pobieranie zawartości strony WWW
4. Serializacja binarna
5. Serializacja XML
6. Serializacja JSON

## Uruchamianie

Najprościej:
- otworzyć wybrany folder,
- otworzyć plik `.csproj` w Visual Studio,
- uruchomić projekt jako aplikację konsolową.

Można też skopiować sam plik `Program.cs` do nowej aplikacji konsolowej .NET Framework.

## Uwaga do serializacji binarnej

`BinaryFormatter` jest pokazany jako przykład historyczny/szkoleniowy dla .NET Framework.
Nie należy używać go produkcyjnie dla danych z niezaufanych źródeł.

## Uwaga do JSON

Przykład JSON używa `JavaScriptSerializer`, dlatego projekt ma dodaną referencję:
`System.Web.Extensions`.
