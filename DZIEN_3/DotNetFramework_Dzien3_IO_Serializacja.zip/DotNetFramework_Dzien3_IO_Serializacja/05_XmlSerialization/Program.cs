using System;
using System.IO;
using System.Xml.Serialization;

namespace XmlSerializationExample
{
    public class Runner
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int StartNumber { get; set; }
        public int TimeInMinutes { get; set; }

        public Runner()
        {
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            string filePath = "runner.xml";

            Runner runner = new Runner();
            runner.FirstName = "Anna";
            runner.LastName = "Nowak";
            runner.StartNumber = 77;
            runner.TimeInMinutes = 275;

            XmlSerializer serializer = new XmlSerializer(typeof(Runner));

            using (FileStream stream = new FileStream(filePath, FileMode.Create))
            {
                serializer.Serialize(stream, runner);
            }

            Console.WriteLine("Obiekt zapisano do XML.");

            Runner loadedRunner;

            using (FileStream stream = new FileStream(filePath, FileMode.Open))
            {
                loadedRunner = (Runner)serializer.Deserialize(stream);
            }

            Console.WriteLine();
            Console.WriteLine("Odczytany zawodnik:");
            Console.WriteLine(loadedRunner.FirstName + " " + loadedRunner.LastName);
            Console.WriteLine("Numer: " + loadedRunner.StartNumber);
            Console.WriteLine("Czas: " + loadedRunner.TimeInMinutes + " minut");

            Console.ReadKey();
        }
    }
}
