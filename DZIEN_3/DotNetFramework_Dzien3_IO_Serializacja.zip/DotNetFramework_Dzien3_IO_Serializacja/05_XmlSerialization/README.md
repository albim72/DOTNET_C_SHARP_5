# 05 - Serializacja XML

Program zapisuje obiekt Runner do pliku XML i potem go odczytuje.

Uruchom projekt `.csproj` w Visual Studio albo skopiuj `Program.cs` do aplikacji konsolowej .NET Framework.
