# 01 - IO: zapis i odczyt pliku tekstowego

Program zapisuje dane zawodnika do pliku runner.txt, a następnie odczytuje je z pliku.

Uruchom projekt `.csproj` w Visual Studio albo skopiuj `Program.cs` do aplikacji konsolowej .NET Framework.
