using System;
using System.IO;

namespace FileWriteReadExample
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath = "runner.txt";

            Console.Write("Podaj imię zawodnika: ");
            string name = Console.ReadLine();

            Console.Write("Podaj numer startowy: ");
            string number = Console.ReadLine();

            string content = "Imię: " + name + Environment.NewLine +
                             "Numer startowy: " + number;

            File.WriteAllText(filePath, content);

            Console.WriteLine();
            Console.WriteLine("Dane zapisano do pliku.");

            string readContent = File.ReadAllText(filePath);

            Console.WriteLine();
            Console.WriteLine("Zawartość pliku:");
            Console.WriteLine(readContent);

            Console.ReadKey();
        }
    }
}
