using System;
using System.IO;
using System.Web.Script.Serialization;

namespace JsonSerializationExample
{
    public class Runner
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int StartNumber { get; set; }
        public int TimeInMinutes { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            string filePath = "runner.json";

            Runner runner = new Runner();
            runner.FirstName = "Piotr";
            runner.LastName = "Wiśniewski";
            runner.StartNumber = 301;
            runner.TimeInMinutes = 292;

            JavaScriptSerializer serializer = new JavaScriptSerializer();

            string json = serializer.Serialize(runner);

            File.WriteAllText(filePath, json);

            Console.WriteLine("Obiekt zapisano do JSON.");
            Console.WriteLine(json);

            string loadedJson = File.ReadAllText(filePath);

            Runner loadedRunner = serializer.Deserialize<Runner>(loadedJson);

            Console.WriteLine();
            Console.WriteLine("Odczytany zawodnik:");
            Console.WriteLine(loadedRunner.FirstName + " " + loadedRunner.LastName);
            Console.WriteLine("Numer: " + loadedRunner.StartNumber);
            Console.WriteLine("Czas: " + loadedRunner.TimeInMinutes + " minut");

            Console.ReadKey();
        }
    }
}
