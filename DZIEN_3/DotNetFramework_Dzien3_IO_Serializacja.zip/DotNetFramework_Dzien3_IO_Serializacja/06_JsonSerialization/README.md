# 06 - Serializacja JSON

Program zapisuje obiekt Runner do pliku JSON i potem go odczytuje. Wymaga referencji System.Web.Extensions.

Uruchom projekt `.csproj` w Visual Studio albo skopiuj `Program.cs` do aplikacji konsolowej .NET Framework.
