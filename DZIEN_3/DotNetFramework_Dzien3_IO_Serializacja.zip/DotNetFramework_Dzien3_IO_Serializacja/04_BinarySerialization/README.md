# 04 - Serializacja binarna

Program zapisuje obiekt Runner do pliku binarnego, a następnie go odczytuje. Przykład szkoleniowy dla .NET Framework.

Uruchom projekt `.csproj` w Visual Studio albo skopiuj `Program.cs` do aplikacji konsolowej .NET Framework.
