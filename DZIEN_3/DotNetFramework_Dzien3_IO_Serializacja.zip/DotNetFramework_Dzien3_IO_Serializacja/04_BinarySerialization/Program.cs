using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace BinarySerializationExample
{
    [Serializable]
    public class Runner
    {
        public string FirstName;
        public string LastName;
        public int StartNumber;
        public int TimeInMinutes;
    }

    class Program
    {
        static void Main(string[] args)
        {
            string filePath = "runner.bin";

            Runner runner = new Runner();
            runner.FirstName = "Adam";
            runner.LastName = "Kowalski";
            runner.StartNumber = 125;
            runner.TimeInMinutes = 284;

            BinaryFormatter formatter = new BinaryFormatter();

            using (FileStream stream = new FileStream(filePath, FileMode.Create))
            {
                formatter.Serialize(stream, runner);
            }

            Console.WriteLine("Obiekt zapisano binarnie.");

            Runner loadedRunner;

            using (FileStream stream = new FileStream(filePath, FileMode.Open))
            {
                loadedRunner = (Runner)formatter.Deserialize(stream);
            }

            Console.WriteLine();
            Console.WriteLine("Odczytany zawodnik:");
            Console.WriteLine(loadedRunner.FirstName + " " + loadedRunner.LastName);
            Console.WriteLine("Numer: " + loadedRunner.StartNumber);
            Console.WriteLine("Czas: " + loadedRunner.TimeInMinutes + " minut");

            Console.ReadKey();
        }
    }
}
