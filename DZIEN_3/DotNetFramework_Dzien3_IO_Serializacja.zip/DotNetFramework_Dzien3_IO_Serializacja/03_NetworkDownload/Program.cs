using System;
using System.Net;
using System.IO;

namespace NetworkDownloadExample
{
    class Program
    {
        static void Main(string[] args)
        {
            string url = "https://example.com";
            string filePath = "page.html";

            try
            {
                WebClient client = new WebClient();

                string content = client.DownloadString(url);

                File.WriteAllText(filePath, content);

                Console.WriteLine("Pobrano stronę:");
                Console.WriteLine(url);

                Console.WriteLine();
                Console.WriteLine("Zapisano wynik do pliku:");
                Console.WriteLine(filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Wystąpił błąd:");
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
