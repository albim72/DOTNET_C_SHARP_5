# 03 - Sieć: pobieranie zawartości strony WWW

Program pobiera zawartość strony internetowej i zapisuje ją do pliku page.html.

Uruchom projekt `.csproj` w Visual Studio albo skopiuj `Program.cs` do aplikacji konsolowej .NET Framework.
