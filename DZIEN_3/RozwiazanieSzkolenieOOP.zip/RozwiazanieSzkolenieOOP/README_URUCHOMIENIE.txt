ROZWIĄZANIE ZADANIA INDYWIDUALNEGO - OOP W C# / .NET CORE
============================================================

Projekt: RozwiazanieSzkolenieOOP
Typ: aplikacja konsolowa .NET
Docelowy framework: net8.0

JAK URUCHOMIĆ
-------------
1. Rozpakuj plik ZIP.
2. Otwórz terminal / PowerShell w folderze projektu.
3. Wpisz:

   dotnet run

Jeśli chcesz najpierw zbudować projekt:

   dotnet build
   dotnet run

CO ZAWIERA ROZWIĄZANIE
----------------------
Projekt realizuje pełną treść zadania oraz wersję rozszerzoną.

Elementy podstawowe:
- klasa abstrakcyjna Osoba,
- dziedziczenie: Kursant i Trener dziedziczą po Osoba,
- metoda abstrakcyjna WyswietlRole(),
- interfejs IRaportowalny,
- implementacja interfejsu w klasie Szkolenie,
- klasa ModulSzkoleniowy,
- klasa Harmonogram,
- klasa Szkolenie,
- kolekcje List<T>,
- menu konsolowe,
- dodawanie kursantów,
- dodawanie ocen,
- liczenie średniej,
- wskazywanie najlepszego kursanta,
- generowanie raportu.

Elementy dodatkowe:
- usuwanie kursanta,
- wyszukiwanie kursanta po nazwisku,
- enum PoziomZaawansowania,
- klasa Certyfikat,
- wystawianie certyfikatów zaliczonym kursantom,
- zapis raportu do pliku tekstowego,
- TryParse przy wczytywaniu danych liczbowych,
- obsługa wyjątku przy zapisie raportu.

RELACJE OBIEKTOWE W KODZIE
--------------------------
Dziedziczenie:
- Kursant : Osoba
- Trener : Osoba

Klasa abstrakcyjna:
- Osoba

Interfejs:
- IRaportowalny
- Szkolenie : IRaportowalny

Agregacja:
- Szkolenie ma listę istniejących kursantów: List<Kursant>
- Kursanci są tworzeni jako osobne obiekty i dodawani do szkolenia.

Kompozycja:
- Szkolenie tworzy własny Harmonogram w konstruktorze.

STRUKTURA PLIKÓW
----------------
Program.cs
AplikacjaSzkoleniowa.cs
Osoba.cs
Kursant.cs
Trener.cs
IRaportowalny.cs
PoziomZaawansowania.cs
ModulSzkoleniowy.cs
Harmonogram.cs
Szkolenie.cs
Certyfikat.cs
RozwiazanieSzkolenieOOP.csproj
