namespace RozwiazanieSzkolenieOOP;

public class Kursant : Osoba
{
    private readonly List<int> _oceny;

    public int NumerUczestnika { get; private set; }
    public Certyfikat? Certyfikat { get; private set; }

    public IReadOnlyList<int> Oceny
    {
        get { return _oceny.AsReadOnly(); }
    }

    public Kursant(string imie, string nazwisko, int wiek, int numerUczestnika)
        : base(imie, nazwisko, wiek)
    {
        NumerUczestnika = numerUczestnika;
        _oceny = new List<int>();
    }

    public bool DodajOcene(int ocena)
    {
        if (ocena < 1 || ocena > 6)
        {
            return false;
        }

        _oceny.Add(ocena);
        return true;
    }

    public double ObliczSrednia()
    {
        if (_oceny.Count == 0)
        {
            return 0.0;
        }

        int suma = 0;

        foreach (int ocena in _oceny)
        {
            suma += ocena;
        }

        return (double)suma / _oceny.Count;
    }

    public bool CzyZaliczyl()
    {
        return _oceny.Count > 0 && ObliczSrednia() >= 3.0;
    }

    public Certyfikat? UtworzCertyfikat(string nazwaSzkolenia)
    {
        if (!CzyZaliczyl())
        {
            return null;
        }

        Certyfikat ??= new Certyfikat(this, nazwaSzkolenia, ObliczSrednia());
        return Certyfikat;
    }

    public void WyswietlOceny()
    {
        if (_oceny.Count == 0)
        {
            Console.WriteLine("Oceny: brak");
            return;
        }

        Console.WriteLine("Oceny: " + string.Join(", ", _oceny));
    }

    public override void WyswietlPodstawoweDane()
    {
        base.WyswietlPodstawoweDane();
        Console.WriteLine($"Numer uczestnika: {NumerUczestnika}");
        WyswietlOceny();
        Console.WriteLine($"Średnia: {ObliczSrednia():F2}");
        Console.WriteLine($"Status: {(CzyZaliczyl() ? "zaliczył" : "nie zaliczył")}");

        if (Certyfikat is not null)
        {
            Console.WriteLine($"Certyfikat: {Certyfikat.NumerCertyfikatu}");
        }
    }

    public override void WyswietlRole()
    {
        Console.WriteLine("Rola: kursant");
    }
}
