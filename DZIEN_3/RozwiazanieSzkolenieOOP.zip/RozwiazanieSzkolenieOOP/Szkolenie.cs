using System.Text;

namespace RozwiazanieSzkolenieOOP;

public class Szkolenie : IRaportowalny
{
    private readonly List<Kursant> _kursanci;

    public string Nazwa { get; private set; }
    public PoziomZaawansowania Poziom { get; private set; }
    public Trener Trener { get; private set; }

    // Kompozycja: Szkolenie samo tworzy i posiada własny Harmonogram.
    public Harmonogram Harmonogram { get; private set; }

    public IReadOnlyList<Kursant> Kursanci
    {
        get { return _kursanci.AsReadOnly(); }
    }

    public Szkolenie(string nazwa, PoziomZaawansowania poziom, Trener trener)
    {
        Nazwa = nazwa;
        Poziom = poziom;
        Trener = trener;
        _kursanci = new List<Kursant>();
        Harmonogram = new Harmonogram();
    }

    // Agregacja: do szkolenia dodajemy istniejący obiekt Kursant.
    public void DodajKursanta(Kursant kursant)
    {
        _kursanci.Add(kursant);
    }

    public bool UsunKursantaPoNumerze(int numerUczestnika)
    {
        Kursant? kursant = ZnajdzKursantaPoNumerze(numerUczestnika);

        if (kursant is null)
        {
            return false;
        }

        _kursanci.Remove(kursant);
        return true;
    }

    public Kursant? ZnajdzKursantaPoNumerze(int numerUczestnika)
    {
        foreach (Kursant kursant in _kursanci)
        {
            if (kursant.NumerUczestnika == numerUczestnika)
            {
                return kursant;
            }
        }

        return null;
    }

    public List<Kursant> SzukajKursantowPoNazwisku(string nazwisko)
    {
        List<Kursant> wyniki = new List<Kursant>();

        foreach (Kursant kursant in _kursanci)
        {
            if (kursant.Nazwisko.Contains(nazwisko, StringComparison.OrdinalIgnoreCase))
            {
                wyniki.Add(kursant);
            }
        }

        return wyniki;
    }

    public Kursant? ZnajdzNajlepszegoKursanta()
    {
        if (_kursanci.Count == 0)
        {
            return null;
        }

        Kursant? najlepszy = null;

        foreach (Kursant kursant in _kursanci)
        {
            if (kursant.Oceny.Count == 0)
            {
                continue;
            }

            if (najlepszy is null || kursant.ObliczSrednia() > najlepszy.ObliczSrednia())
            {
                najlepszy = kursant;
            }
        }

        return najlepszy;
    }

    public void WyswietlInformacjeOSzkoleniu()
    {
        Console.WriteLine($"Nazwa szkolenia: {Nazwa}");
        Console.WriteLine($"Poziom: {Poziom}");
        Console.WriteLine($"Trener: {Trener}");
        Console.WriteLine($"Liczba kursantów: {_kursanci.Count}");
        Console.WriteLine($"Liczba modułów: {Harmonogram.Moduly.Count}");
        Console.WriteLine($"Łączna liczba godzin: {Harmonogram.ObliczLacznaLiczbeGodzin()}");
    }

    public void WyswietlTrenera()
    {
        Trener.WyswietlPodstawoweDane();
        Trener.WyswietlRole();
    }

    public void WyswietlKursantow()
    {
        if (_kursanci.Count == 0)
        {
            Console.WriteLine("Brak kursantów w szkoleniu.");
            return;
        }

        Console.WriteLine("Lista kursantów:");

        foreach (Kursant kursant in _kursanci)
        {
            Console.WriteLine($"[{kursant.NumerUczestnika}] {kursant.Imie} {kursant.Nazwisko}, średnia: {kursant.ObliczSrednia():F2}, status: {(kursant.CzyZaliczyl() ? "zaliczył" : "nie zaliczył")}");
        }
    }

    public List<Certyfikat> WystawCertyfikaty()
    {
        List<Certyfikat> certyfikaty = new List<Certyfikat>();

        foreach (Kursant kursant in _kursanci)
        {
            Certyfikat? certyfikat = kursant.UtworzCertyfikat(Nazwa);

            if (certyfikat is not null)
            {
                certyfikaty.Add(certyfikat);
            }
        }

        return certyfikaty;
    }

    public string GenerujRaport()
    {
        StringBuilder raport = new StringBuilder();

        raport.AppendLine("================ RAPORT SZKOLENIA ================");
        raport.AppendLine($"Nazwa szkolenia: {Nazwa}");
        raport.AppendLine($"Poziom: {Poziom}");
        raport.AppendLine($"Trener: {Trener.Imie} {Trener.Nazwisko} ({Trener.Specjalizacja})");
        raport.AppendLine($"Liczba kursantów: {_kursanci.Count}");
        raport.AppendLine($"Liczba modułów: {Harmonogram.Moduly.Count}");
        raport.AppendLine($"Łączna liczba godzin: {Harmonogram.ObliczLacznaLiczbeGodzin()}");
        raport.AppendLine();

        raport.AppendLine("MODUŁY SZKOLENIOWE:");
        if (Harmonogram.Moduly.Count == 0)
        {
            raport.AppendLine("Brak modułów.");
        }
        else
        {
            int licznik = 1;
            foreach (ModulSzkoleniowy modul in Harmonogram.Moduly)
            {
                raport.AppendLine($"{licznik}. {modul}");
                licznik++;
            }
        }

        raport.AppendLine();
        raport.AppendLine("KURSANCI:");

        if (_kursanci.Count == 0)
        {
            raport.AppendLine("Brak kursantów.");
        }
        else
        {
            foreach (Kursant kursant in _kursanci)
            {
                string oceny = kursant.Oceny.Count == 0 ? "brak" : string.Join(", ", kursant.Oceny);
                raport.AppendLine($"- [{kursant.NumerUczestnika}] {kursant.Imie} {kursant.Nazwisko}, oceny: {oceny}, średnia: {kursant.ObliczSrednia():F2}, status: {(kursant.CzyZaliczyl() ? "zaliczył" : "nie zaliczył")}");
            }
        }

        raport.AppendLine();
        Kursant? najlepszy = ZnajdzNajlepszegoKursanta();

        if (najlepszy is null)
        {
            raport.AppendLine("Najlepszy kursant: brak danych, ponieważ nikt nie ma jeszcze ocen.");
        }
        else
        {
            raport.AppendLine($"Najlepszy kursant: {najlepszy.Imie} {najlepszy.Nazwisko}, średnia: {najlepszy.ObliczSrednia():F2}");
        }

        raport.AppendLine();
        raport.AppendLine("CERTYFIKATY:");
        bool znalezionoCertyfikat = false;

        foreach (Kursant kursant in _kursanci)
        {
            if (kursant.Certyfikat is not null)
            {
                raport.AppendLine(kursant.Certyfikat.ToString());
                znalezionoCertyfikat = true;
            }
        }

        if (!znalezionoCertyfikat)
        {
            raport.AppendLine("Brak wystawionych certyfikatów.");
        }

        raport.AppendLine("===================================================");

        return raport.ToString();
    }

    public void ZapiszRaportDoPliku(string sciezkaPliku)
    {
        string? katalog = Path.GetDirectoryName(sciezkaPliku);

        if (!string.IsNullOrWhiteSpace(katalog))
        {
            Directory.CreateDirectory(katalog);
        }

        File.WriteAllText(sciezkaPliku, GenerujRaport(), Encoding.UTF8);
    }
}
