namespace RozwiazanieSzkolenieOOP;

public class Trener : Osoba
{
    public string Specjalizacja { get; private set; }

    public Trener(string imie, string nazwisko, int wiek, string specjalizacja)
        : base(imie, nazwisko, wiek)
    {
        Specjalizacja = specjalizacja;
    }

    public override void WyswietlPodstawoweDane()
    {
        base.WyswietlPodstawoweDane();
        Console.WriteLine($"Specjalizacja: {Specjalizacja}");
    }

    public override void WyswietlRole()
    {
        Console.WriteLine("Rola: trener");
    }
}
