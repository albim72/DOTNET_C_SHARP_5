using System.Text;

namespace RozwiazanieSzkolenieOOP;

internal class Program
{
    private static void Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.InputEncoding = Encoding.UTF8;

        AplikacjaSzkoleniowa aplikacja = new AplikacjaSzkoleniowa();
        aplikacja.Uruchom();
    }
}
