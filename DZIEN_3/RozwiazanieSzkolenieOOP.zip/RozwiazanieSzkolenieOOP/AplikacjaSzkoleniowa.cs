namespace RozwiazanieSzkolenieOOP;

public class AplikacjaSzkoleniowa
{
    private readonly Szkolenie _szkolenie;
    private int _nastepnyNumerUczestnika;

    public AplikacjaSzkoleniowa()
    {
        Trener trener = new Trener("Marcin", "Albiniak", 53, "C# / .NET / sztuczna inteligencja");
        _szkolenie = new Szkolenie("Podstawy .NET", PoziomZaawansowania.Podstawowy, trener);
        _nastepnyNumerUczestnika = 1;

        PrzygotujDaneStartowe();
    }

    public void Uruchom()
    {
        bool czyDziala = true;

        while (czyDziala)
        {
            PokazMenu();
            int wybor = WczytajInt("Wybierz opcję: ", 0, 11);
            Console.WriteLine();

            switch (wybor)
            {
                case 1:
                    _szkolenie.WyswietlInformacjeOSzkoleniu();
                    break;
                case 2:
                    _szkolenie.WyswietlTrenera();
                    break;
                case 3:
                    DodajKursantaZKonsoli();
                    break;
                case 4:
                    _szkolenie.WyswietlKursantow();
                    break;
                case 5:
                    DodajOceneKursantowi();
                    break;
                case 6:
                    _szkolenie.Harmonogram.WyswietlHarmonogram();
                    break;
                case 7:
                    Console.WriteLine(_szkolenie.GenerujRaport());
                    break;
                case 8:
                    SzukajKursantaPoNazwisku();
                    break;
                case 9:
                    UsunKursanta();
                    break;
                case 10:
                    ZapiszRaportDoPliku();
                    break;
                case 11:
                    WystawCertyfikaty();
                    break;
                case 0:
                    czyDziala = false;
                    Console.WriteLine("Koniec programu.");
                    break;
            }

            if (czyDziala)
            {
                Console.WriteLine();
                Console.WriteLine("Naciśnij Enter, aby wrócić do menu...");
                Console.ReadLine();
            }
        }
    }

    private void PrzygotujDaneStartowe()
    {
        _szkolenie.Harmonogram.DodajModul(new ModulSzkoleniowy(
            "Zmienne i typy danych",
            2,
            "Podstawowe typy, zmienne, operatory i wczytywanie danych z konsoli.",
            PoziomZaawansowania.Podstawowy));

        _szkolenie.Harmonogram.DodajModul(new ModulSzkoleniowy(
            "Instrukcje warunkowe i pętle",
            3,
            "if, switch, for, while oraz proste algorytmy konsolowe.",
            PoziomZaawansowania.Podstawowy));

        _szkolenie.Harmonogram.DodajModul(new ModulSzkoleniowy(
            "Klasy i obiekty",
            4,
            "Tworzenie własnych typów danych, pól, metod i konstruktorów.",
            PoziomZaawansowania.Podstawowy));

        _szkolenie.Harmonogram.DodajModul(new ModulSzkoleniowy(
            "Dziedziczenie i klasa abstrakcyjna",
            4,
            "Klasy bazowe, klasy potomne, metoda abstrakcyjna i override.",
            PoziomZaawansowania.Sredni));

        _szkolenie.Harmonogram.DodajModul(new ModulSzkoleniowy(
            "Interfejsy, agregacja i kompozycja",
            5,
            "Projektowanie relacji między obiektami i kontraktów zachowania.",
            PoziomZaawansowania.Sredni));

        Kursant anna = new Kursant("Anna", "Nowak", 29, _nastepnyNumerUczestnika++);
        anna.DodajOcene(5);
        anna.DodajOcene(4);
        anna.DodajOcene(5);

        Kursant piotr = new Kursant("Piotr", "Kowalski", 34, _nastepnyNumerUczestnika++);
        piotr.DodajOcene(3);
        piotr.DodajOcene(4);

        Kursant ewa = new Kursant("Ewa", "Zielińska", 26, _nastepnyNumerUczestnika++);
        ewa.DodajOcene(2);
        ewa.DodajOcene(3);

        _szkolenie.DodajKursanta(anna);
        _szkolenie.DodajKursanta(piotr);
        _szkolenie.DodajKursanta(ewa);
    }

    private static void PokazMenu()
    {
        Console.Clear();
        Console.WriteLine("=====================================");
        Console.WriteLine(" SYSTEM SZKOLENIA - PODSTAWY .NET");
        Console.WriteLine("=====================================");
        Console.WriteLine("1. Wyświetl informacje o szkoleniu");
        Console.WriteLine("2. Wyświetl trenera");
        Console.WriteLine("3. Dodaj kursanta");
        Console.WriteLine("4. Wyświetl kursantów");
        Console.WriteLine("5. Dodaj ocenę kursantowi");
        Console.WriteLine("6. Wyświetl harmonogram");
        Console.WriteLine("7. Wygeneruj raport szkolenia");
        Console.WriteLine("8. Wyszukaj kursanta po nazwisku");
        Console.WriteLine("9. Usuń kursanta");
        Console.WriteLine("10. Zapisz raport do pliku tekstowego");
        Console.WriteLine("11. Wystaw certyfikaty zaliczonym kursantom");
        Console.WriteLine("0. Zakończ program");
        Console.WriteLine("=====================================");
    }

    private void DodajKursantaZKonsoli()
    {
        Console.WriteLine("Dodawanie kursanta");
        string imie = WczytajTekst("Podaj imię: ");
        string nazwisko = WczytajTekst("Podaj nazwisko: ");
        int wiek = WczytajInt("Podaj wiek: ", 1, 120);

        Kursant kursant = new Kursant(imie, nazwisko, wiek, _nastepnyNumerUczestnika++);
        _szkolenie.DodajKursanta(kursant);

        Console.WriteLine($"Dodano kursanta: {kursant.Imie} {kursant.Nazwisko}, numer: {kursant.NumerUczestnika}");
    }

    private void DodajOceneKursantowi()
    {
        _szkolenie.WyswietlKursantow();
        Console.WriteLine();

        int numer = WczytajInt("Podaj numer uczestnika: ", 1, int.MaxValue);
        Kursant? kursant = _szkolenie.ZnajdzKursantaPoNumerze(numer);

        if (kursant is null)
        {
            Console.WriteLine("Nie znaleziono kursanta o podanym numerze.");
            return;
        }

        int ocena = WczytajInt("Podaj ocenę od 1 do 6: ", 1, 6);

        if (kursant.DodajOcene(ocena))
        {
            Console.WriteLine("Ocena została dodana.");
            Console.WriteLine($"Nowa średnia kursanta {kursant.Imie} {kursant.Nazwisko}: {kursant.ObliczSrednia():F2}");
        }
        else
        {
            Console.WriteLine("Niepoprawna ocena. Ocena musi być w zakresie 1-6.");
        }
    }

    private void SzukajKursantaPoNazwisku()
    {
        string nazwisko = WczytajTekst("Podaj nazwisko lub fragment nazwiska: ");
        List<Kursant> wyniki = _szkolenie.SzukajKursantowPoNazwisku(nazwisko);

        if (wyniki.Count == 0)
        {
            Console.WriteLine("Nie znaleziono kursantów.");
            return;
        }

        Console.WriteLine("Wyniki wyszukiwania:");

        foreach (Kursant kursant in wyniki)
        {
            Console.WriteLine($"[{kursant.NumerUczestnika}] {kursant.Imie} {kursant.Nazwisko}, średnia: {kursant.ObliczSrednia():F2}");
        }
    }

    private void UsunKursanta()
    {
        _szkolenie.WyswietlKursantow();
        Console.WriteLine();

        int numer = WczytajInt("Podaj numer uczestnika do usunięcia: ", 1, int.MaxValue);
        bool usunieto = _szkolenie.UsunKursantaPoNumerze(numer);

        if (usunieto)
        {
            Console.WriteLine("Kursant został usunięty ze szkolenia.");
        }
        else
        {
            Console.WriteLine("Nie znaleziono kursanta o podanym numerze.");
        }
    }

    private void ZapiszRaportDoPliku()
    {
        string nazwaPliku = "raport_szkolenia.txt";
        string sciezka = Path.Combine(AppContext.BaseDirectory, nazwaPliku);

        try
        {
            _szkolenie.ZapiszRaportDoPliku(sciezka);
            Console.WriteLine($"Raport zapisano do pliku: {sciezka}");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Nie udało się zapisać raportu.");
            Console.WriteLine($"Szczegóły błędu: {ex.Message}");
        }
    }

    private void WystawCertyfikaty()
    {
        List<Certyfikat> certyfikaty = _szkolenie.WystawCertyfikaty();

        if (certyfikaty.Count == 0)
        {
            Console.WriteLine("Nie wystawiono certyfikatów. Żaden kursant nie spełnia warunku zaliczenia.");
            return;
        }

        Console.WriteLine("Wystawione certyfikaty:");

        foreach (Certyfikat certyfikat in certyfikaty)
        {
            certyfikat.WyswietlCertyfikat();
            Console.WriteLine();
        }
    }

    private static string WczytajTekst(string komunikat)
    {
        while (true)
        {
            Console.Write(komunikat);
            string? tekst = Console.ReadLine();

            if (!string.IsNullOrWhiteSpace(tekst))
            {
                return tekst.Trim();
            }

            Console.WriteLine("Wartość nie może być pusta.");
        }
    }

    private static int WczytajInt(string komunikat, int min, int max)
    {
        while (true)
        {
            Console.Write(komunikat);
            string? tekst = Console.ReadLine();

            if (int.TryParse(tekst, out int liczba) && liczba >= min && liczba <= max)
            {
                return liczba;
            }

            Console.WriteLine($"Podaj liczbę całkowitą z zakresu {min}-{max}.");
        }
    }
}
