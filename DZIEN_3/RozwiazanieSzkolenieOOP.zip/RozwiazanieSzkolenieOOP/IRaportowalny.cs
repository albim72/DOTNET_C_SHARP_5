namespace RozwiazanieSzkolenieOOP;

public interface IRaportowalny
{
    string GenerujRaport();
}
