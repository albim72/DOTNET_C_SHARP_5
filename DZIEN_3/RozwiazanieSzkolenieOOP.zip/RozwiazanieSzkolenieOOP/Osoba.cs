namespace RozwiazanieSzkolenieOOP;

public abstract class Osoba
{
    public string Imie { get; protected set; }
    public string Nazwisko { get; protected set; }
    public int Wiek { get; protected set; }

    protected Osoba(string imie, string nazwisko, int wiek)
    {
        Imie = imie;
        Nazwisko = nazwisko;
        Wiek = wiek;
    }

    public virtual void WyswietlPodstawoweDane()
    {
        Console.WriteLine($"Imię: {Imie}");
        Console.WriteLine($"Nazwisko: {Nazwisko}");
        Console.WriteLine($"Wiek: {Wiek}");
    }

    public abstract void WyswietlRole();

    public override string ToString()
    {
        return $"{Imie} {Nazwisko}";
    }
}
