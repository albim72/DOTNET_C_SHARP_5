namespace RozwiazanieSzkolenieOOP;

public enum PoziomZaawansowania
{
    Podstawowy = 1,
    Sredni = 2,
    Zaawansowany = 3
}
