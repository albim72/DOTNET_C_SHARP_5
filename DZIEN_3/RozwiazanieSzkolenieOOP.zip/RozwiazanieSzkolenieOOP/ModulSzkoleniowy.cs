namespace RozwiazanieSzkolenieOOP;

public class ModulSzkoleniowy
{
    public string Nazwa { get; private set; }
    public int LiczbaGodzin { get; private set; }
    public string Opis { get; private set; }
    public PoziomZaawansowania Poziom { get; private set; }

    public ModulSzkoleniowy(string nazwa, int liczbaGodzin, string opis, PoziomZaawansowania poziom)
    {
        Nazwa = nazwa;
        LiczbaGodzin = liczbaGodzin;
        Opis = opis;
        Poziom = poziom;
    }

    public void WyswietlModul()
    {
        Console.WriteLine($"- {Nazwa} ({LiczbaGodzin} h, poziom: {Poziom})");
        Console.WriteLine($"  Opis: {Opis}");
    }

    public override string ToString()
    {
        return $"{Nazwa} | {LiczbaGodzin} h | poziom: {Poziom} | {Opis}";
    }
}
