namespace RozwiazanieSzkolenieOOP;

public class Harmonogram
{
    private readonly List<ModulSzkoleniowy> _moduly;

    public IReadOnlyList<ModulSzkoleniowy> Moduly
    {
        get { return _moduly.AsReadOnly(); }
    }

    public Harmonogram()
    {
        _moduly = new List<ModulSzkoleniowy>();
    }

    public void DodajModul(ModulSzkoleniowy modul)
    {
        _moduly.Add(modul);
    }

    public int ObliczLacznaLiczbeGodzin()
    {
        int suma = 0;

        foreach (ModulSzkoleniowy modul in _moduly)
        {
            suma += modul.LiczbaGodzin;
        }

        return suma;
    }

    public void WyswietlHarmonogram()
    {
        if (_moduly.Count == 0)
        {
            Console.WriteLine("Harmonogram jest pusty.");
            return;
        }

        Console.WriteLine("Harmonogram szkolenia:");

        for (int i = 0; i < _moduly.Count; i++)
        {
            Console.Write($"{i + 1}. ");
            _moduly[i].WyswietlModul();
        }

        Console.WriteLine($"Łączna liczba godzin: {ObliczLacznaLiczbeGodzin()}");
    }
}
