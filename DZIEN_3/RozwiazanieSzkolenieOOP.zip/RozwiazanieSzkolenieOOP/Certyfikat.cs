namespace RozwiazanieSzkolenieOOP;

public class Certyfikat
{
    public string NumerCertyfikatu { get; private set; }
    public string ImieNazwiskoKursanta { get; private set; }
    public string NazwaSzkolenia { get; private set; }
    public DateTime DataWystawienia { get; private set; }
    public double SredniaOcen { get; private set; }

    public Certyfikat(Kursant kursant, string nazwaSzkolenia, double sredniaOcen)
    {
        NumerCertyfikatu = "CERT-" + DateTime.Now.ToString("yyyyMMdd") + "-" + Guid.NewGuid().ToString("N")[..8].ToUpper();
        ImieNazwiskoKursanta = kursant.ToString();
        NazwaSzkolenia = nazwaSzkolenia;
        DataWystawienia = DateTime.Now;
        SredniaOcen = sredniaOcen;
    }

    public void WyswietlCertyfikat()
    {
        Console.WriteLine("----- CERTYFIKAT -----");
        Console.WriteLine($"Numer: {NumerCertyfikatu}");
        Console.WriteLine($"Kursant: {ImieNazwiskoKursanta}");
        Console.WriteLine($"Szkolenie: {NazwaSzkolenia}");
        Console.WriteLine($"Data wystawienia: {DataWystawienia:yyyy-MM-dd}");
        Console.WriteLine($"Średnia ocen: {SredniaOcen:F2}");
    }

    public override string ToString()
    {
        return $"{NumerCertyfikatu} | {ImieNazwiskoKursanta} | {NazwaSzkolenia} | {DataWystawienia:yyyy-MM-dd} | średnia: {SredniaOcen:F2}";
    }
}
