﻿using RunApp_chat;
using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("=== Race Cutoff Judge ===");
        Console.WriteLine();

        Console.Write("Podaj imię zawodnika: ");
        string imie = Console.ReadLine();

        Console.Write("Podaj nazwisko zawodnika: ");
        string nazwisko = Console.ReadLine();

        Console.Write("Podaj numer startowy: ");
        int numerStartowy = int.Parse(Console.ReadLine());

        Console.Write("Podaj czas na punkcie w minutach: ");
        int czasNaPunkcieWMinutach = int.Parse(Console.ReadLine());

        Runner runner = new Runner(
            imie,
            nazwisko,
            numerStartowy,
            czasNaPunkcieWMinutach
        );

        CutoffJudge judge = new CutoffJudge(290, 15);

        string message = judge.GenerateMessage(runner);

        Console.WriteLine();
        Console.WriteLine("=== Wynik oceny ===");
        Console.WriteLine(message);

        Console.WriteLine();
        Console.WriteLine("Naciśnij dowolny klawisz, aby zakończyć...");
        Console.ReadKey();
    }
}
