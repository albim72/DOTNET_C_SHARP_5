﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RunApp_chat
{
    internal class Runner
    {
        public string Imie { get; set; }
        public string Nazwisko { get; set; }
        public int NumerStartowy { get; set; }
        public int CzasNaPunkcieWMinutach { get; set; }

        public Runner(string imie, string nazwisko, int numerStartowy, int czasNaPunkcieWMinutach)
        {
            Imie = imie;
            Nazwisko = nazwisko;
            NumerStartowy = numerStartowy;
            CzasNaPunkcieWMinutach = czasNaPunkcieWMinutach;
        }

        public string GetFullName()
        {
            return Imie + " " + Nazwisko;
        }
    }
}
