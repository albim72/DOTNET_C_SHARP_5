﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RunApp_chat
{
    internal class CutoffJudge
    {
        public int LimitCzasuWMinutach { get; set; }
        public int ProgOstrzezeniaWMinutach { get; set; }

        public CutoffJudge(int limitCzasuWMinutach, int progOstrzezeniaWMinutach)
        {
            LimitCzasuWMinutach = limitCzasuWMinutach;
            ProgOstrzezeniaWMinutach = progOstrzezeniaWMinutach;
        }

        public DecisionStatus Judge(Runner runner)
        {
            int czasZawodnika = runner.CzasNaPunkcieWMinutach;
            int zapasCzasu = LimitCzasuWMinutach - czasZawodnika;

            if (czasZawodnika > LimitCzasuWMinutach)
            {
                return DecisionStatus.DNF;
            }

            if (zapasCzasu <= ProgOstrzezeniaWMinutach)
            {
                return DecisionStatus.WARNING;
            }

            return DecisionStatus.OK;
        }

        public string GenerateMessage(Runner runner)
        {
            DecisionStatus status = Judge(runner);

            int czasZawodnika = runner.CzasNaPunkcieWMinutach;
            int zapasCzasu = LimitCzasuWMinutach - czasZawodnika;

            if (status == DecisionStatus.DNF)
            {
                int opoznienie = czasZawodnika - LimitCzasuWMinutach;

                return runner.GetFullName()
                    + " nie zmieścił się w limicie. Przekroczenie limitu: "
                    + opoznienie + " minut. Status: DNF.";
            }

            if (status == DecisionStatus.WARNING)
            {
                return runner.GetFullName()
                    + " mieści się w limicie, ale ma mały zapas czasu: "
                    + zapasCzasu + " minut. Status: WARNING.";
            }

            return runner.GetFullName()
                + " mieści się w limicie. Zapas czasu: "
                + zapasCzasu + " minut. Status: OK.";
        }
    }
}
