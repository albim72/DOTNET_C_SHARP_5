﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RunApp_chat
{
    public enum DecisionStatus
    {
        OK,
        WARNING,
        DNF
    }
}
